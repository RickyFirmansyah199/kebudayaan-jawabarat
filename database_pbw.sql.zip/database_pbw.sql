-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 18 Jun 2021 pada 02.48
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database_pbw`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `artikel`
--

CREATE TABLE `artikel` (
  `id` int(11) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `deskripsi` mediumtext NOT NULL,
  `tangaldibuat` date NOT NULL,
  `foto` varchar(100) NOT NULL,
  `kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `artikel`
--

INSERT INTO `artikel` (`id`, `judul`, `deskripsi`, `tangaldibuat`, `foto`, `kategori`) VALUES
(1, 'BAJU ADAT', '   Pakaian Adat Jawa Barat sudah melekat pada budaya Sunda. Budaya Sunda adalah salah satu kebudayaan tertua di Indonesia. Banyak \r\n        sekali ragam dan bentuk budaya jawa barat khususnya sunda yang sangat khas. Dan beberapa diantaranya adalah warisan leluhur yang \r\n        tak ternilai harganya dan harus dipertahankan. Selain dari pada nilai-nilai kesopanan luhur yang dijunjung tinggi, kita mengenal \r\n        begitu banyak peninggalan budaya leluhur yang tentu harus senantiasa dilestarikan selamanya.\r\n            Pakaian adat tradisional Jawa Barat dapat dibagi menjadi 3 buah kelompok strata sosial yaitu pakaian untuk para bangsawan \r\n        (menak), pakaian untuk masyarakat kelas menengah dan pakaian untuk masyarakat kelas bawah, penjelasan lengkapnya sebagai berikut.\r\n\r\n        Pakaian Adat Untuk Acara Pernikahan\r\n\r\n            Pengantin Pria\r\n        Untuk pengantin pria biasanya menggunakan jas tutup berwarna putih lengkap dengan ikat pinggang berwarna seragam. Terdapat kain \r\n        rereng yang berfungsi sebagai bawahan dan tutup kepala bermotif rereng. Terdapat aksesoris berupa kalung panjang yang terbuat dari \r\n        bunga melati dan senjata sebagai hiasan dalam pengantin pria.\r\n            Pengantin Wanita\r\n        Untuk pengantin wanita, mereka menggunakan kebaya brukat berwarna putih dengan bawahan berupa kain rereng eneng. Busana ini lengkap \r\n        dengan ikat pinggang berwarna emas yang seringkali disebut benten. Sedangkan untuk aksesoris yang digunakan ialah kalung panjang, \r\n        perhiasan kilat batu, kalung giwang, cincin, bros dan lain sebagainya. Terdapat ciri khas berupa sanggul pada rambut dengan hiasan \r\n        berupa untaian bunga sedap malam serta bunga tujuh kembang goyang.\r\n\r\n        Pakaian Adat Untuk Acara Resmi\r\n\r\n        Pada acara resmi, baru-baru ini masyarakat Jawa Barat membuat standar baku untuk pemakaian pakaian untuk acara-acara resmi, seperti \r\n        yang ditampilkan pada pemilihan tahunan mojang dan jajaka. Mojang yang berarti perempuan muda, menggunakan pakaian berupa kebaya \r\n        polos yang dihiasi dengan kain sulam serta kain kebat, beubeur, kamisol, karembong dan alas kaki berupa selop yang dapat \r\n        diselaraskan dengan warna kebaya yang digunakan. Terdapat aksesoris berupa tusuk konde lengkap dengan hiasan bunga untuk rambut, \r\n        giwang, bros dan cincin yang terbuat dari bahan dasar emas. Sedangkan untuk jajaka yang berarti laki-laki muda, mereka menggunakan \r\n        jas tutup dengan warna yang polos beragam dan bagian bawahan berupa celana panjang dengan warna yang disesuaikan dengan atasan. \r\n        Busana ini lengkap dengan kain samping yang diletakan di pinggang, penutup kepala, arloji rantai di saku depan, dan alas kaki \r\n        berupa selop.', '2021-06-17', 'Gambar/baju_adat1.jpeg', '0'),
(2, 'JAIPONG', 'tari tradisional', '2021-06-17', 'Gambar/jaipong.jpeg', '0'),
(3, 'Rumah Adat', 'rumah tradisional', '2021-06-17', 'Gambar/rumah_adat.jpeg', '0'),
(4, 'SEREN TAUN', 'Seren Taun merupakan salah satu upacara adat yang dilakukan oleh masyarakat Sunda pada saat panen padi setiap tahun. Sebuah \r\n        ritual dengan nuansa sakral dimana didalamnya sarat akan makna. Seren Taun merupakan symbol atau ungkapan syukur atas apa yang \r\n        telah dilakukan dan diraih selama bercocok tanam. Khususnya tanaman padi. Upacara ini berlangsung khidmat dan semarak di berbagai \r\n        desa adat Sunda. Upacara adat sebagai syukuran masyarakat agraris ini diramaikan ribuan masyarakat sekitarnya, bahkan dari beberapa \r\n        daerah di Jawa Barat dan mancanegara. Salah satunya, Desa Purwabakti Kecamatan Pamijahan, Kabupaten Bogor – Jawa Barat. Sebuah \r\n        desa yang masih tetap memegang teguh nilai-nilai budaya peninggalan leluhur.\r\n            \r\n            “Seren Taun, mengandung pesan-pesan moral yang begitu tinggi untuk bisa menikmati. Mensyukuri dan menghormati atas semua nikmat \r\n        yang telah di berikan tuhan melalui alam ini,” ungkap Mulyadi, MM selaku Kepala Desa setempat. Menurut lelaki yang akrab dipanggil \r\n        Ki Lurah ini, Seren Taun atau Sedekah Bumi adalah menyerahkan tahun yang sudah dan menerima tahun yang akan datang. Tujuannya adalah \r\n        untuk mengingatkan bahwa kita hidup di alam, maka jangan merusak alam. “Dan, harus mensyukuri atas segala nikmat yang alam berikan. \r\n        Timbal baliknya, jangan hanya bisa menanam tapi harus menjaga lewat sedekah bumi,” ujar Mulyadi. \r\n            \r\n            Pesan moral Seren Tahun, menurut Ki Lurah Mulyadi:\r\n        “Kita harus bisa memberikan manfaat walaupun kecil. Tutulung kanu butuh tatalang kanu susah. Kita harus yakin ke Tuhan Yang Maha \r\n        Esa. Tapi ingat, kata Tuhan jangankan minta ke Dia. Karena, tanpa di pintapun Tuhan pasti akan memberi. Karena Tuhan maha memberi \r\n        dan sudah menyediakan semua untuk kita. Pintalah ke orang tua, ibu, bapak, nenek dan kakek kita. Kalau berbuat dosa ke orang tua \r\n        kita bagaimana kita akan memiliki dunia,”', '2021-06-18', 'Gambar/seren_tahun.jpeg', 'tradisi'),
(5, 'WAYANG', ' Pada mulanya yang dilakonkan dalam wayang golek adalah ceritera panji dan wayangnya disebut wayang golek menak. Konon, wayang \r\n        golek ini baru ada sejak masa Panembahan Ratu (cicit Sunan Gunung Jati (1540-1650)). Di sana (di daerah Cirebon) disebut sebagai\r\n        wayang golek papak atau wayang cepak karena bentuk kepalanya datar. Pada zaman Pangeran Girilaya (1650-1662) wayang cepak \r\n        dilengkapi dengan cerita yang diambil dari babad dan sejarah tanah Jawa. Lakon-lakon yang dibawakan waktu itu berkisar pada \r\n        penyebaran agama Islam. Selanjutnya, wayang golek dengan lakon Ramayana dan Mahabarata (wayang golek purwa) yang lahir pada 1840 \r\n        (Somantri, 1988).  da tiga jenis wayang golek, yaitu: wayang golek cepak, wayang golek purwa, dan wayang golek modern. Wayang \r\n        golek papak (cepak) terkenal di Cirebon dengan ceritera babad dan legenda serta menggunakan bahasa Cirebon. Wayang golek purwa \r\n        adalah wayang golek khusus membawakan cerita Mahabharata dan Ramayana dengan pengantar bahasa Sunda sebagai. Sedangkan, wayang \r\n        golek modern seperti wayang purwa (ceritanya tentang Mahabarata dan Ramayana, tetapi dalam pementasannya menggunakan listrik 1\r\n        untuk membuat trik-trik.\r\n\r\n            Pembuatan\r\n            Wayang golek terbuat dari albasiah atau lame. Cara pembuatannya adalah dengan meraut dan mengukirnya, hingga menyerupai bentuk \r\n        yang diinginkan. Untuk mewarnai dan menggambar mata, alis, bibir dan motif di kepala wayang, digunakan cat duko. Cat ini \r\n        menjadikan wayang tampak lebih cerah. Pewarnaan wayang merupakan bagian penting karena dapat menghasilkan berbagai karakter tokoh. \r\n        Adapun warna dasar yang biasa digunakan dalam wayang ada empat yaitu: merah, putih, prada, dan hitam.\r\n            \r\n            Nilai Budaya\r\n            Wayang golek sebagai suatu kesenian tidak hanya mengandung nilai estetika semata, tetapi meliputi keseluruhan nilai-nilai yang \r\n        terdapat dalam masyarakat pendukungnya. Nilai-nilai itu disosialisasikan oleh para seniman dan seniwati pedalangan yang mengemban \r\n        kode etik pedalangan. Kode etik pedalangan tersebut dinamakan \"Sapta Sila Kehormatan Seniman Seniwati Pedalangan Jawa Barat\". \r\n        Rumusan kode etik pedalangan tersebut merupakan hasil musyawarah para seniman seniwati pedalangan pada tanggal 28 Februari 1964 \r\n        di Bandung. Isinya antara lain sebagai berikut: Satu: Seniman dan seniwati pedalangan adalah seniman sejati sebab itu harus\r\n        menjaga nilainya. Dua: Mendidik masyarakat. Itulah sebabnya diwajibkan memberi con-toh, baik dalam bentuk ucapan maupun tingkah \r\n        laku. Tiga: Juru penerang. Karena itu diwajibkan menyampaikan pesan-pesan atau membantu pemerintah serta menyebarkan segala \r\n        cita-cita negara bangsanya kepada masyarakat. Empat: Sosial Indonesia. Sebab itu diwajibkan mengukuhi jiwa gotong-royong dalam \r\n        segala masalah. Lima: Susilawan. Diwajibkan menjaga etika di lingkungan masyarakat. Enam: Mempunyai kepribadian sendiri, maka \r\n        diwajibkan menjaga kepribadian sendiri dan bangsa. Tujuh: Setiawan. Maka diwajibkan tunduk dan taat, serta menghormati hukum \r\n        Republik Indonesia, demikian pula terhadap adat-istiadat bangsa.\r\n            ', '2021-06-18', 'Gambar/wayang.jpeg', ''),
(6, 'ANGKLUNG', '  Angklung adalah salah satu alat musik tradisional Indonesia yang dikenal  dan berkembang dari daerah jawa barat, nama \r\n        angklung ini sendiri berasal dari bahasa daerah jawa barat yaitu bahasa Sunda Angkleung-angkleungan yang berarti \r\n        enggambarkan gerak tubuh para pemain angklung yang berayun atau bergerak sesuai irama yang dihasilkan angklung. Alat \r\n        musik ini terbuat dari bambu dan dimainkan dengan cara menggoyangkannya sehingga akan tercipta nada nada dari hasil \r\n        getaran atau bunyi benturan tabung bambunya.\r\n            Di masa lamapau angklung tidak merupakan kesenian murni melainkan juga dapat  digunakan pada acara acara yang merupakan \r\n        tradisi atau perayaan masyarakat Sunda ,yang pada sejarahnya yaitu untuk mengiringi ritual pemanggilan dewi sri \r\n        ( dewi padi) yang bertujuan untuk meminta kemakmuran untuk tanaman padi yang di tanam masyrakat.\r\n            ', '0000-00-00', 'Gambar/angklung.jpeg', 'seni musik');

-- --------------------------------------------------------

--
-- Struktur dari tabel `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `id_artikel` int(11) NOT NULL,
  `Nama` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Comment` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `comment`
--

INSERT INTO `comment` (`id`, `id_artikel`, `Nama`, `Email`, `Comment`) VALUES
(1, 2, 'ricky', 'rickyfirmansyah199@gmail.com', 'bagus hahaha'),
(2, 2, 'yohana', 'yohana@gmail.com', 'bagus dong');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_artikel` (`id_artikel`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `artikel`
--
ALTER TABLE `artikel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`id_artikel`) REFERENCES `artikel` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
